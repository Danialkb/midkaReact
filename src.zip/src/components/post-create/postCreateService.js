import axios from "axios";

export const createPost = async (title, body) => {
    await axios.post("/posts/", {
        title: title,
        body: body,
    })
}