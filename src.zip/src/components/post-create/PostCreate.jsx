import React, {useState} from 'react';
import MyInput from "../../ui/input/MyInput";
import MyButton from "../../ui/button/MyButton";
import {createPost} from "./postCreateService";
import {useNavigate} from "react-router-dom";

const PostCreate = () => {
    const [title, setTitle] = useState("");
    const [body, setBody] = useState("");
    const navigate = useNavigate();

    const create = async () => {
        await createPost(title, body);
        navigate("/");
    }

    return (
        <div>
            <h2>Создайте свой пост!</h2>
            <MyInput type="text" onChange={(e) => setTitle(e.target.value)} placeholder="Название..."></MyInput>
            <MyInput type="text" onChange={(e) => setBody(e.target.value)} placeholder="Текст..."></MyInput>
            <MyButton type="submit" onClick={create}>Создать</MyButton>
        </div>
    );
};

export default PostCreate;