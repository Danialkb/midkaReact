import React, {memo, useEffect, useState} from 'react';
import {useNavigate, useParams} from "react-router-dom";
import {getPost} from "./PostItemService";
import MyButton from "../../ui/button/MyButton";
import axios from "axios";

const PostItem = () => {
    const { id } = useParams();
    const [post, setPost] = useState({});
    const [comment, setComment] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        getPost(id).then((data) => setPost(data))
    }, [id]);

    const del = async () => {
        await axios.delete(`/posts/${id}/`);
        navigate("/");
    }

    // const createComment = async () => {
    //     await axios.post()
    // }

    const like = async () => {
        await axios.post(`/posts/${id}/like/`);
        window.location.reload();
    }

    return (
        <div>
            <h1>{post.title}</h1>
            <h3>{post.body}</h3>
            <h4>Likes: {post.likes}</h4>
            <MyButton onClick={del}>Delete</MyButton>
            <MyButton onClick={like} >Like</MyButton>
            <div>
                <textarea value={comment} placeholder="Оставьте комментарий"></textarea>
            </div>
        </div>
    );
};

export default memo(PostItem);