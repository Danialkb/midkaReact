import axios from "axios";

export const getPost = async (id) => {
    console.log("ID" + " " + id)
    const resp = await axios.get(`/posts/${id}/` );
    return resp.data;
}