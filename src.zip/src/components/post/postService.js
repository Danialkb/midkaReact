import axios from "axios";

export const getPosts = async() => {
    const resp = await axios.get("/posts/");
    return resp.data;
}

export const searchPost = async(title) => {
    try {
        const response = await axios.get(`/posts?search=${title}`);
        return response.data;
    } catch (error) {
        throw error;
    }
}