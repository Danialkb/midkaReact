import React, {memo, useEffect, useState} from 'react';
import SearchBar from "../search/SearchBar";
import MyButton from "../../ui/button/MyButton";
import {getPosts, searchPost} from "./postService";
import "./PostList.css";
import {useNavigate} from "react-router-dom";


const PostList = () => {
    const [posts, setPosts] = useState([]);
    const navigate = useNavigate();


    useEffect(() => {
        getPosts().then((posts) => setPosts(posts));
    }, []);

    const onSearchSubmit = (searchText) => {
        searchPost(searchText).then((data) => setPosts(data))
    };

    return (
        <div>
            <SearchBar onSearchSubmit={onSearchSubmit}/>

            <MyButton onClick={() => navigate("/create-post")}>Создать Пост</MyButton>
            <h3 onClick={() => navigate("/profile")}>Мой профиль</h3>
            <div className="post-list">
                {posts.map((post) => (
                    <div className="post-item">
                        <h4 className="link" onClick={() => navigate(`/posts/${post.id}`)}>{post.title}</h4>
                        <p className="link">{post.body}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default memo(PostList);