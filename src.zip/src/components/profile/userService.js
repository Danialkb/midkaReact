import axios from "axios";

export const getUser = async (id) => {
    const resp = await axios.get("/users/" + id + "/");
    return resp.data;
}