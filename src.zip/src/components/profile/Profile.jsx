import React, {memo, useEffect, useState} from 'react';
import MyInput from "../../ui/input/MyInput";
import {getUser} from "./userService";

const Profile = () => {
    const [user, setUser] = useState({});

    useEffect(() => {
        getUser(2).then((data) => setUser(data))
    });

    return (
        <div>
            <MyInput value={user.first_name}></MyInput>
            <MyInput value={user.last_name}></MyInput>
            <MyInput value={user.email}></MyInput>
            <img src={user.avatar} />
        </div>
    );
};

export default memo(Profile);