import './App.css';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import PostList from "./components/post/PostList";
import PostCreate from "./components/post-create/PostCreate";
import PostItem from "./components/post-item/PostItem";
import Profile from "./components/profile/Profile";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<PostList/>}/>
          <Route path="/profile" element={<Profile/>}/>
          <Route path="/create-post" element={<PostCreate/>}/>
          <Route path="/posts/:id" element={<PostItem/>}/>

            <Route path="*"  element={<PostList/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
